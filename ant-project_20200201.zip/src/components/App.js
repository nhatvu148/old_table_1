import React from "react";
import AppTable from "./AppTable";

const App = () => {
  return <AppTable />;
};

export default App;
